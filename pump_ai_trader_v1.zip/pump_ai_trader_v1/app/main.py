import asyncio, json, logging, os, random, sqlite3, time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional

import httpx
import websockets
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("pump-ai-trader")

DB_PATH = os.getenv("DB_PATH", "./pump_trader.db")
START_BALANCE = float(os.getenv("START_BALANCE", "1000"))
POSITION_SIZE = float(os.getenv("POSITION_SIZE", "25"))
STOP_LOSS = float(os.getenv("STOP_LOSS", "0.10"))
TAKE_PROFIT = float(os.getenv("TAKE_PROFIT", "0.20"))
MAX_POSITIONS = int(os.getenv("MAX_POSITIONS", "5"))
MAX_DAILY_LOSS = float(os.getenv("MAX_DAILY_LOSS", "0.05"))
RUN_DAYS = int(os.getenv("RUN_DAYS", "7"))
MARKET_DATA_MODE = os.getenv("MARKET_DATA_MODE", "mock").lower()
PUMPPORTAL_API_KEY = os.getenv("PUMPPORTAL_API_KEY", "")
XAI_API_KEY = os.getenv("XAI_API_KEY", "")
XAI_MODEL = os.getenv("XAI_MODEL", "grok-4.7")

state = {"running": False, "mode": "paper", "feed": MARKET_DATA_MODE,
         "started_at": None, "last_event_at": None, "feed_status": "not_started",
         "grok_status": "disabled" if not XAI_API_KEY else "configured"}
task: Optional[asyncio.Task] = None
prices = {}
day_start_equity = START_BALANCE
current_utc_day = datetime.now(timezone.utc).date()
stop_event = asyncio.Event()

def db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS account (
            id INTEGER PRIMARY KEY CHECK(id=1), cash REAL NOT NULL,
            realized_pnl REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS tokens (
            mint TEXT PRIMARY KEY, symbol TEXT, name TEXT, first_seen TEXT,
            last_price REAL, score REAL DEFAULT 0, ai_note TEXT DEFAULT '')""")
        c.execute("""CREATE TABLE IF NOT EXISTS positions (
            mint TEXT PRIMARY KEY, symbol TEXT, qty REAL, entry_price REAL,
            cost REAL, opened_at TEXT, status TEXT DEFAULT 'open',
            exit_price REAL, pnl REAL DEFAULT 0, closed_at TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, symbol TEXT,
            side TEXT, price REAL, qty REAL, notional REAL, fee REAL,
            pnl REAL, reason TEXT, created_at TEXT)""")
        row = c.execute("SELECT id FROM account WHERE id=1").fetchone()
        if not row:
            c.execute("INSERT INTO account(id,cash,created_at) VALUES(1,?,?)",
                      (START_BALANCE, datetime.now(timezone.utc).isoformat()))

def account():
    with db() as c:
        return dict(c.execute("SELECT * FROM account WHERE id=1").fetchone())

def open_positions():
    with db() as c:
        return [dict(x) for x in c.execute(
            "SELECT * FROM positions WHERE status='open'").fetchall()]

def equity():
    a = account()
    return a["cash"] + sum(p["qty"] * prices.get(p["mint"], p["entry_price"])
                           for p in open_positions())

async def grok_review(token: dict) -> tuple[float, str]:
    """Grok can veto/annotate; deterministic risk rules remain authoritative."""
    if not XAI_API_KEY:
        return 0.0, "Grok not configured; deterministic scoring only"
    prompt = {
        "token": token,
        "instruction": "Assess only observable launch/trade metadata. Return JSON with "
                       "risk_score from 0 to 100 (100=highest risk) and short reason. "
                       "Do not predict price or promise returns."
    }
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                "https://api.x.ai/v1/responses",
                headers={"Authorization": f"Bearer {XAI_API_KEY}"},
                json={"model": XAI_MODEL, "input": json.dumps(prompt),
                      "text": {"format": {"type": "json_object"}}}
            )
            r.raise_for_status()
            data = r.json()
        text_out = ""
        for item in data.get("output", []):
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    text_out += part.get("text", "")
        parsed = json.loads(text_out) if text_out else {}
        return float(parsed.get("risk_score", 100)), str(parsed.get("reason", "No explanation"))
    except Exception as e:
        log.warning("Grok review failed: %s", e)
        return 100.0, "Grok unavailable; fail-closed"

def deterministic_score(token: dict) -> float:
    # Conservative metadata-only score. Higher is better.
    score = 50.0
    if token.get("symbol"): score += 5
    if token.get("name"): score += 5
    if token.get("initialBuy"): score += 5
    if token.get("marketCapSol"): score += 5
    if token.get("uri"): score += 3
    return min(100.0, score)

async def consider_token(token: dict):
    mint = token.get("mint") or token.get("tokenMint")
    if not mint:
        return
    symbol = str(token.get("symbol") or "UNKNOWN")[:20]
    name = str(token.get("name") or symbol)[:80]
    price = token.get("price")
    try:
        price = float(price) if price else None
    except (TypeError, ValueError):
        price = None
    if not price or price <= 0:
        # No valid price: record token, wait for a valid trade event.
        price = None
    base_score = deterministic_score(token)
    risk, note = await grok_review(token) if XAI_API_KEY else (0.0, "Grok disabled")
    final_score = base_score - (risk * 0.35)
    with db() as c:
        c.execute("""INSERT INTO tokens(mint,symbol,name,first_seen,last_price,score,ai_note)
                     VALUES(?,?,?,?,?,?,?) ON CONFLICT(mint) DO UPDATE SET
                     symbol=excluded.symbol,name=excluded.name,
                     last_price=COALESCE(excluded.last_price,tokens.last_price),
                     score=excluded.score,ai_note=excluded.ai_note""",
                  (mint, symbol, name, datetime.now(timezone.utc).isoformat(),
                   price, final_score, note))
    if price:
        prices[mint] = price
        await maybe_buy(mint, symbol, price, final_score)

async def maybe_buy(mint: str, symbol: str, price: float, score: float):
    if not state["running"] or score < 45:
        return
    positions = open_positions()
    if any(p["mint"] == mint for p in positions) or len(positions) >= MAX_POSITIONS:
        return
    a = account()
    if a["cash"] < POSITION_SIZE:
        return
    # Reset the daily loss baseline at each UTC day boundary.
    global day_start_equity, current_utc_day
    today = datetime.now(timezone.utc).date()
    if today != current_utc_day:
        current_utc_day = today
        day_start_equity = equity()
    if equity() <= day_start_equity * (1 - MAX_DAILY_LOSS):
        state["running"] = False
        state["feed_status"] = "stopped_daily_loss_limit"
        return
    qty = POSITION_SIZE / price
    fee = POSITION_SIZE * 0.01  # conservative 1% simulated round-trip-side cost
    with db() as c:
        c.execute("UPDATE account SET cash=cash-? WHERE id=1", (POSITION_SIZE + fee,))
        c.execute("""INSERT INTO positions(mint,symbol,qty,entry_price,cost,opened_at)
                     VALUES(?,?,?,?,?,?)""",
                  (mint, symbol, qty, price, POSITION_SIZE + fee,
                   datetime.now(timezone.utc).isoformat()))
        c.execute("""INSERT INTO trades(mint,symbol,side,price,qty,notional,fee,pnl,reason,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (mint, symbol, "BUY", price, qty, POSITION_SIZE, fee, 0,
                   "score_threshold", datetime.now(timezone.utc).isoformat()))
    log.info("PAPER BUY %s %s @ %.10f", symbol, mint, price)

async def maybe_sell(mint: str, price: float):
    with db() as c:
        p = c.execute("SELECT * FROM positions WHERE mint=? AND status='open'", (mint,)).fetchone()
        if not p: return
        p = dict(p)
        change = price / p["entry_price"] - 1
        reason = "stop_loss" if change <= -STOP_LOSS else (
                 "take_profit" if change >= TAKE_PROFIT else None)
        if not reason: return
        gross = p["qty"] * price
        fee = gross * 0.01
        proceeds = gross - fee
        pnl = proceeds - p["cost"]
        c.execute("UPDATE account SET cash=cash+?, realized_pnl=realized_pnl+? WHERE id=1",
                  (proceeds, pnl))
        c.execute("""UPDATE positions SET status='closed',exit_price=?,pnl=?,closed_at=?
                     WHERE mint=?""",
                  (price, pnl, datetime.now(timezone.utc).isoformat(), mint))
        c.execute("""INSERT INTO trades(mint,symbol,side,price,qty,notional,fee,pnl,reason,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (mint, p["symbol"], "SELL", price, p["qty"], gross, fee, pnl,
                   reason, datetime.now(timezone.utc).isoformat()))
    log.info("PAPER SELL %s @ %.10f pnl=%.4f (%s)", p["symbol"], price, pnl, reason)

async def handle_trade(event: dict):
    mint = event.get("mint") or event.get("tokenMint")
    if not mint: return
    sol = event.get("solAmount")
    tokens = event.get("tokenAmount")
    try:
        price = float(sol) / float(tokens)
    except (TypeError, ValueError, ZeroDivisionError):
        price = None
    if not price or price <= 0: return
    prices[mint] = price
    state["last_event_at"] = datetime.now(timezone.utc).isoformat()
    with db() as c:
        c.execute("UPDATE tokens SET last_price=? WHERE mint=?", (price, mint))
    await maybe_sell(mint, price)
    row = None
    with db() as c:
        row = c.execute("SELECT symbol,score FROM tokens WHERE mint=?", (mint,)).fetchone()
    if row:
        await maybe_buy(mint, row["symbol"], price, row["score"])

async def pumpportal_loop():
    if not PUMPPORTAL_API_KEY:
        state["feed_status"] = "missing_api_key"
        log.warning("No PumpPortal API key; live feed unavailable.")
        return
    url = f"wss://pumpportal.fun/api/data?api-key={PUMPPORTAL_API_KEY}"
    state["feed_status"] = "connecting"
    subscribed = set()
    while state["running"]:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20) as ws:
                await ws.send(json.dumps({"method": "subscribeNewToken"}))
                state["feed_status"] = "connected_new_tokens"
                async for raw in ws:
                    if not state["running"]: break
                    try: event = json.loads(raw)
                    except json.JSONDecodeError: continue
                    state["last_event_at"] = datetime.now(timezone.utc).isoformat()
                    if event.get("txType") in ("buy", "sell") and (event.get("mint") or event.get("tokenMint")):
                        await handle_trade(event)
                    else:
                        mint = event.get("mint") or event.get("tokenMint")
                        if mint:
                            await consider_token(event)
                            if mint not in subscribed:
                                await ws.send(json.dumps({"method": "subscribeTokenTrade", "keys": [mint]}))
                                subscribed.add(mint)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            state["feed_status"] = "reconnecting"
            log.warning("PumpPortal connection error: %s", e)
            await asyncio.sleep(5)

async def mock_loop():
    """Deterministic-seeded synthetic feed for safe end-to-end testing."""
    random.seed(42)
    state["feed_status"] = "mock_synthetic_data"
    demo = [{"mint": f"DEMO{i}", "symbol": f"DEMO{i}", "name": f"Demo token {i}",
             "uri": "synthetic", "initialBuy": True, "marketCapSol": 20,
             "price": 0.001 + i * 0.0001} for i in range(1, 9)]
    for token in demo:
        await consider_token(token)
    while state["running"]:
        for mint in list(prices):
            prices[mint] *= random.uniform(0.965, 1.045)
            await maybe_sell(mint, prices[mint])
            row = None
            with db() as c:
                row = c.execute("SELECT symbol,score FROM tokens WHERE mint=?", (mint,)).fetchone()
            if row: await maybe_buy(mint, row["symbol"], prices[mint], row["score"])
        state["last_event_at"] = datetime.now(timezone.utc).isoformat()
        await asyncio.sleep(3)

async def run_engine():
    try:
        if MARKET_DATA_MODE == "live":
            await asyncio.wait_for(pumpportal_loop(), timeout=RUN_DAYS * 86400)
        else:
            await asyncio.wait_for(mock_loop(), timeout=RUN_DAYS * 86400)
    except asyncio.TimeoutError:
        state["feed_status"] = "seven_day_run_completed"
    finally:
        state["running"] = False

class StartRequest(BaseModel):
    confirm_paper_only: bool = True

@asynccontextmanager
async def lifespan(app: FastAPI):
    global task
    init_db()
    yield
    if task:
        task.cancel()

app = FastAPI(title="Pump AI Trader v1.0", lifespan=lifespan)

@app.get("/")
def root():
    return {"app": "Pump AI Trader", "mode": "paper_only", "status": "ready",
            "warning": "No on-chain trading is implemented or enabled."}

@app.get("/health")
def health():
    return {"ok": True, "mode": "paper_only"}

@app.post("/bot/start")
async def start_bot(req: StartRequest):
    global task, day_start_equity, current_utc_day
    if not req.confirm_paper_only:
        raise HTTPException(400, "Paper-only confirmation required.")
    if state["running"]:
        return {"status": "already_running"}
    state["running"] = True
    state["started_at"] = datetime.now(timezone.utc).isoformat()
    day_start_equity = equity()
    current_utc_day = datetime.now(timezone.utc).date()
    stop_event.clear()
    task = asyncio.create_task(run_engine())
    return {"status": "started", "mode": "paper_only", "feed": MARKET_DATA_MODE}

@app.post("/bot/stop")
async def stop_bot():
    state["running"] = False
    if task:
        task.cancel()
    state["feed_status"] = "stopped"
    return {"status": "stopped"}

@app.get("/bot/status")
def bot_status():
    a = account()
    pos = open_positions()
    unrealized = sum(p["qty"] * prices.get(p["mint"], p["entry_price"]) - p["cost"] for p in pos)
    return {**state, "cash": round(a["cash"], 4), "equity": round(equity(), 4),
            "realized_pnl": round(a["realized_pnl"], 4),
            "unrealized_pnl": round(unrealized, 4),
            "open_positions": len(pos), "duration_days": RUN_DAYS,
            "simulation_only": True}

@app.get("/positions")
def positions():
    result = open_positions()
    for p in result:
        p["mark_price"] = prices.get(p["mint"], p["entry_price"])
        p["unrealized_pnl"] = p["qty"] * p["mark_price"] - p["cost"]
    return result

@app.get("/trades")
def trades(limit: int = 100):
    limit = max(1, min(limit, 500))
    with db() as c:
        return [dict(x) for x in c.execute(
            "SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

@app.get("/report")
def report():
    a = account()
    with db() as c:
        closed = c.execute("SELECT COUNT(*) n, SUM(pnl) pnl FROM positions WHERE status='closed'").fetchone()
        wins = c.execute("SELECT COUNT(*) FROM positions WHERE status='closed' AND pnl>0").fetchone()[0]
        losses = c.execute("SELECT COUNT(*) FROM positions WHERE status='closed' AND pnl<=0").fetchone()[0]
    total = (closed["n"] or 0)
    return {"initial_balance": START_BALANCE, "cash": a["cash"],
            "equity": equity(), "realized_pnl": a["realized_pnl"],
            "closed_trades": total, "wins": wins, "losses": losses,
            "win_rate_pct": round(100*wins/total, 2) if total else 0,
            "note": "Paper simulation only; live-mode results depend on actual market data availability."}
