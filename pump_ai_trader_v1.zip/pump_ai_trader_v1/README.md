# Pump AI Trader v1.0 — paper trading only

This starter is deliberately **paper-only**. It contains no wallet, private-key,
signing, swap, or on-chain transaction code.

## What is included
- FastAPI service and endpoints for start/stop/status/positions/trades/report.
- SQLite persistence. On Railway, attach a persistent volume mounted at `/data`.
- Simulated order accounting with configurable position size, stop-loss,
  take-profit, position cap and daily loss circuit breaker.
- Optional xAI/Grok metadata review. Grok can only reduce the score; deterministic
  rules control paper orders. If Grok fails, the token is rejected (fail-closed).
- Mock feed is the default and uses synthetic prices. **Mock results are not market
  performance and must never be presented as real trading results.**

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000/docs`.

Start the simulation:
```bash
curl -X POST http://127.0.0.1:8000/bot/start \
  -H 'Content-Type: application/json' -d '{"confirm_paper_only": true}'
```
Stop:
```bash
curl -X POST http://127.0.0.1:8000/bot/stop
```

## Railway deployment
1. Push this folder to a **private GitHub repository**.
2. Railway → New Project → Deploy from GitHub Repo → select the repository.
3. Add a Railway Volume mounted at `/data` (SQLite persistence).
4. Add variables from `.env.example`. Keep `MARKET_DATA_MODE=mock` for initial checks.
5. Generate a domain under service Networking. `/health` is the health check;
   `/docs` exposes the API interface.
6. Use `/bot/start` to start the 7-day paper run; `/bot/status` and `/report`
   show results. The worker automatically stops after seven days. Stop earlier with `/bot/stop`.

## Grok
Create an xAI API key in the xAI Console and set `XAI_API_KEY` as a Railway
secret variable. The app uses `POST https://api.x.ai/v1/responses`. API usage
may incur charges. Keep the key private; never commit it to GitHub.

## Live Pump.fun feed — caution
The default feed is synthetic. A live data adapter is included but is **not
enabled by default**. To attempt it, set `MARKET_DATA_MODE=live` and configure
`PUMPPORTAL_API_KEY`. PumpPortal documents a single WebSocket connection,
free `subscribeNewToken`, and metered `subscribeTokenTrade`; the latter may
require a linked wallet with at least 0.02 SOL and incurs provider fees. This
does not execute trades, but it is not necessarily cost-free data access.
Review PumpPortal's current terms and charges before enabling it. Do not fund a
wallet or add private keys for this paper-only project.

## Important limitations before interpreting results
- Token metadata and early trade feeds are incomplete and can be manipulated.
- The current strategy is a prototype, not a validated edge.
- Simulated 1% fee per side is a placeholder assumption, not a live fee quote.
- Market impact, queue position, latency, failed transactions, MEV and liquidity
  impact are not fully modelled.
- A seven-day run is a smoke test, not statistically meaningful evidence.
- No real-money trading or wallet integration is provided.
